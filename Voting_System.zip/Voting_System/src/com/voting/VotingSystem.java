package com.voting;
import java.util.ArrayList;
import java.util.Scanner;

public class VotingSystem {

    static Scanner sc = new Scanner(System.in);

    static ArrayList<Voter> voters = new ArrayList<>();

    static ArrayList<Candidate> candidates = new ArrayList<>();

    static class Voter {

        int voterId;
        String name;
        int age;
        boolean hasVoted;

        Voter(int voterId, String name, int age) {
            this.voterId = voterId;
            this.name = name;
            this.age = age;
            this.hasVoted = false;
        }
    }


    // ==============================
    // CANDIDATE CLASS
    // ==============================

    static class Candidate {

        int candidateId;
        String name;
        int voteCount;

        Candidate(int candidateId, String name) {
            this.candidateId = candidateId;
            this.name = name;
            this.voteCount = 0;
        }
    }


    public static void main(String[] args) {

        candidates.add(new Candidate(1, "Arun"));
        candidates.add(new Candidate(2, "Priya"));
        candidates.add(new Candidate(3, "Rahul"));
        candidates.add(new Candidate(4, "Sneha"));

        while (true) {

            System.out.println("\n=================================");
            System.out.println("        VOTING SYSTEM");
            System.out.println("=================================");

            System.out.println("1. Register Voter");
            System.out.println("2. Display Candidates");
            System.out.println("3. Cast Vote");
            System.out.println("4. Display Voting Count");
            System.out.println("5. Exit");

            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    registerVoter();
                    break;

                case 2:
                    displayCandidates();
                    break;

                case 3:
                    castVote();
                    break;

                case 4:
                    displayVotingCount();
                    break;

                case 5:
                    System.out.println("Thank you for using Voting System!");
                    return;

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }


    static void registerVoter() {

        System.out.println("\n========== VOTER REGISTRATION ==========");

        System.out.print("Enter 4-digit Voter ID: ");
        int voterId = sc.nextInt();

        if (voterId < 1000 || voterId > 9999) {

            System.out.println(
                    "Invalid Voter ID! ID must contain exactly 4 digits.");

            return;
        }

        for (Voter voter : voters) {

            if (voter.voterId == voterId) {

                System.out.println(
                        "This Voter ID is already registered.");

                return;
            }
        }

        sc.nextLine();

        System.out.print("Enter voter name: ");
        String name = sc.nextLine();

        if (!name.matches("[a-zA-Z ]+")) {

            System.out.println(
                    "Invalid name! Name can contain only letters and spaces.");

            return;
        }

        name = name.trim();

        System.out.print("Enter age: ");
        int age = sc.nextInt();

        if (age <= 18) {

            System.out.println(
                    "You are not eligible to vote.");

            return;
        }

        Voter voter = new Voter(voterId, name, age);

        voters.add(voter);

        System.out.println(
                "Voter registered successfully!");

        System.out.println("Voter ID : " + voterId);
        System.out.println("Name     : " + name);
        System.out.println("Age      : " + age);
    }

    static void displayCandidates() {

        System.out.println("\n========== CANDIDATES ==========");

        for (Candidate candidate : candidates) {

            System.out.println(
                    "Candidate ID : " + candidate.candidateId);

            System.out.println(
                    "Candidate Name : " + candidate.name);

            System.out.println("-----------------------------");
        }
    }

    static void castVote() {

        System.out.println("\n========== CAST VOTE ==========");

        System.out.print("Enter your Voter ID: ");
        int voterId = sc.nextInt();

        Voter currentVoter = null;

        // Find voter
        for (Voter voter : voters) {

            if (voter.voterId == voterId) {

                currentVoter = voter;
                break;
            }
        }

        // Voter not registered
        if (currentVoter == null) {

            System.out.println(
                    "Voter not found! Please register first.");

            return;
        }

        // Check whether already voted
        if (currentVoter.hasVoted) {

            System.out.println(
                    "You have already voted!");

            return;
        }

        displayCandidates();

        System.out.print("Enter Candidate ID: ");
        int candidateId = sc.nextInt();

        Candidate selectedCandidate = null;

        for (Candidate candidate : candidates) {

            if (candidate.candidateId == candidateId) {

                selectedCandidate = candidate;
                break;
            }
        }

        if (selectedCandidate == null) {

            System.out.println(
                    "Invalid Candidate ID!");

            return;
        }

        selectedCandidate.voteCount++;

        currentVoter.hasVoted = true;

        System.out.println(
                "Vote cast successfully!");

        System.out.println(
                "You voted for: " +
                selectedCandidate.name);
    }


    static void displayVotingCount() {

        System.out.println("\n========== VOTING COUNT ==========");

        for (Candidate candidate : candidates) {

            System.out.println(
                    candidate.name +
                    " : " +
                    candidate.voteCount +
                    " votes");
        }
    }
}
